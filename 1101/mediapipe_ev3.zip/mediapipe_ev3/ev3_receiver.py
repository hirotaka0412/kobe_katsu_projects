#!/usr/bin/env python3
"""EV3側。TCPで指令を受信し、受信停止・切断でモーターを停止する。"""
import argparse
import socket
import time

COMMANDS = {'stop': (0, 0), 'forward': (1, 1), 'backward': (-1, -1),
            'left': (-1, 1), 'right': (1, -1)}


def serve_client(connection, apply, watchdog=0.5):
    connection.settimeout(0.05)
    buffer = b''
    last_received = time.monotonic()
    apply('stop')
    try:
        while True:
            if time.monotonic() - last_received >= watchdog:
                return
            try:
                data = connection.recv(1024)
            except socket.timeout:
                continue
            if not data:
                return
            buffer += data
            if len(buffer) > 4096:
                return
            while b'\n' in buffer:
                raw, buffer = buffer.split(b'\n', 1)
                try:
                    command = raw.decode('ascii')
                except UnicodeDecodeError:
                    return
                if command not in COMMANDS:
                    return
                last_received = time.monotonic()
                apply(command)
    finally:
        apply('stop')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bind', default='0.0.0.0')
    parser.add_argument('--port', type=int, default=5000)
    parser.add_argument('--speed', type=int, default=20)
    args = parser.parse_args()
    if not 1 <= args.speed <= 100:
        parser.error('--speed は1〜100で指定してください')
    from ev3dev2.motor import LargeMotor, OUTPUT_B, OUTPUT_C, SpeedPercent
    left = LargeMotor(OUTPUT_B)
    right = LargeMotor(OUTPUT_C)

    def apply(command):
        a, b = COMMANDS[command]
        if command == 'stop':
            try:
                left.off(brake=True)
            finally:
                right.off(brake=True)
        else:
            left.on(SpeedPercent(a * args.speed))
            right.on(SpeedPercent(b * args.speed))

    try:
        apply('stop')
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.bind((args.bind, args.port))
            server.listen(1)
            print('Waiting for PC on port {}'.format(args.port))
            while True:
                connection, address = server.accept()
                print('Connected: {}'.format(address))
                with connection:
                    try:
                        serve_client(connection, apply)
                    except OSError as error:
                        print('Disconnected: {}'.format(error))
    finally:
        apply('stop')


if __name__ == '__main__':
    main()
