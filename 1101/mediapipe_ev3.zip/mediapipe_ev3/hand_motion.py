"""手の現在位置と握りの状態から指令を判定する。"""
import math


def distance(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)


def is_fist(points):
    # 親指以外の3指以上が曲がっているかの簡易判定。
    return sum(distance(points[tip], points[0]) <
               distance(points[pip], points[0]) * 1.15
               for tip, pip in ((8, 6), (12, 10), (16, 14), (20, 18))) >= 3


class MotionController:
    def __init__(self, dead_zone=0.18):
        # 画面中央から幅・高さの18%以内を停止領域にする。
        self.dead_zone = dead_zone

    def reset(self):
        # 移動履歴を使用しないため、初期化する状態はない。
        pass

    def update(self, points, now=None):
        if not points or is_fist(points):
            return 'stop'
        palm = [points[i] for i in (0, 5, 9, 13, 17)]
        x = sum(p.x for p in palm) / len(palm)
        y = sum(p.y for p in palm) / len(palm)
        dx, dy = x - 0.5, y - 0.5
        if max(abs(dx), abs(dy)) <= self.dead_zone:
            return 'stop'
        if abs(dx) > abs(dy):
            return 'right' if dx > 0 else 'left'
        return 'backward' if dy > 0 else 'forward'
