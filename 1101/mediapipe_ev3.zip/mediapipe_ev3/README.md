# 手の動きでEV3を操作する

PCで手を認識し、BluetoothのIP接続上でTCP指令をEV3へ送信します。
SSHと同じEV3のIPアドレスを使います。EV3にはMediaPipeは不要です。

| 開いた手の位置 | 動作 |
| --- | --- |
| 上 | 前進 |
| 下 | 後退 |
| 左 | 左へその場旋回 |
| 右 | 右へその場旋回 |
| 中央の枠内・握る・手が映らない | 停止 |

手は1つだけ映してください。画面は鏡像で、表示された左右と操作を合わせています。
手の現在位置で判定し、同じ場所に置いている間は動作を継続します。
黄色い枠は停止領域、紫の点は判定に使う手の中心です。
画面中央から幅・高さの18%以内は停止します。斜めは中心からのずれが大きい軸を優先します。
握る判定は親指以外の3指以上の曲がりで判定する簡易方式です。
横向きの手や指の重なりで誤認識し得るため、まず画面で確認してください。
hand_motion.py の dead_zone を大きくすると中央の停止領域が広くなります。


```
Ubuntu PC                         EV3

MediaPipe
   ↓
gesture判定
   ↓
"forward"
   ↓
socket.send()
       ───────────────→    socket.recv()
                              ↓
                         forward()
                              ↓
                           Motor
```

## PCだけで確認

MediaPipeを使用しているPython環境で実行します。依存ライブラリがない場合は先にインストールします。

```powershell
python -m pip install mediapipe opencv-python
cd C:\Users\hirot\Projects_local\ev3_projects\mediapipe_ev3
python hand_director.py
```

同じフォルダーの hand_landmarker.task を読み込み、PREVIEWと判定結果を表示します。
EV3に接続せず使用できます。qキーで終了します。

## Bluetooth接続後

以下の EV3_IP をSSHで使用する実際のIPアドレスに置き換えてください。
PCから受信側のファイルだけを転送します。

```powershell
scp .\ev3_receiver.py robot@ev3dev.local:/home/robot/
ssh robot@ev3dev.local
```

EV3のSSHターミナルで実行します。

```bash
python3 /home/robot/ev3_receiver.py --speed 20
```

PCの別ターミナルで実行します。

```powershell
python hand_director.py --host EV3_IP
```

Bポートが左、Cポートが右です。最初はタイヤを浮かせて方向を確認してください。
取り付けによって方向が逆の場合は ev3_receiver.py の COMMANDS を調整します。
受信側は指令が約0.5秒途切れると停止して接続を閉じます。
PC側の終了、手の消失、カメラ失敗、通信切断でも停止処理を行います。
再接続は自動で行いません。PC側を再起動してください。
受信プログラム自体の強制終了やOSの停止まで停止を保証するものではありません。
受信ポートには認証がないため、接続相手が分かるネットワークで使用してください。
EV3側に --bind EV3_IP を追加するとBluetooth側のIPに待受先を限定できます。

## ファイル構成と検証

- hand_director.py: カメラ・MediaPipe・画面表示・送信（PC側）。同期的に結果を取得するVIDEOモードを使用。
- hand_motion.py: 手の現在位置と握りの判定（PC側）。
- ev3_receiver.py: モーターB/Cの操作と通信の監視（EV3側）。
- main.py: 既存ファイル。変更していません。

```powershell
python -m unittest discover -s tests -v
```

模擬座標とローカル通信のテストです。実際の認識精度や実機での方向・通信は別途確認が必要です。
