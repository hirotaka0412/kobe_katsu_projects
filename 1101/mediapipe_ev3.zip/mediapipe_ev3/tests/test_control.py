import socket
import threading
import unittest
from types import SimpleNamespace

from hand_motion import MotionController
from ev3_receiver import serve_client


def hand(dx=0, dy=0, fist=False):
    points = [SimpleNamespace(x=0.5 + dx, y=0.75 + dy) for _ in range(21)]
    for base, pip, tip in ((5, 6, 8), (9, 10, 12), (13, 14, 16), (17, 18, 20)):
        points[base].y = 0.55 + dy
        points[pip].y = 0.4 + dy
        points[tip].y = (0.65 if fist else 0.2) + dy
    return points


class MotionTests(unittest.TestCase):
    def test_directions(self):
        for dx, dy, expected in ((0.3, 0, 'right'), (-0.3, 0, 'left'),
                                 (0, -0.35, 'forward'), (0, 0.25, 'backward')):
            with self.subTest(expected=expected):
                control = MotionController()
                self.assertEqual(control.update(hand(), 0), 'stop')
                self.assertEqual(control.update(hand(dx, dy), 0.1), expected)
                self.assertEqual(control.update(hand(dx, dy), 10), expected)

    def test_fist_and_lost_hand_reset_motion(self):
        for stopped_hand in (hand(0.2, fist=True), None):
            control = MotionController()
            control.update(hand(), 0)
            self.assertEqual(control.update(hand(0.3), 0.1), 'right')
            self.assertEqual(control.update(stopped_hand, 0.15), 'stop')
            self.assertEqual(control.update(hand(), 0.2), 'stop')

    def test_center_stops_and_stationary_position_keeps_driving(self):
        control = MotionController()
        control.update(hand(), 0)
        self.assertEqual(control.update(hand(0.005), 0.1), 'stop')
        self.assertEqual(control.update(hand(0.3), 0.15), 'right')
        self.assertEqual(control.update(hand(0.3), 0.3), 'right')
        self.assertEqual(control.update(hand(), 1), 'stop')


class ReceiverTests(unittest.TestCase):
    def run_connection(self, packets, disconnect=True):
        server, client = socket.socketpair()
        commands = []
        errors = []

        def run():
            try:
                with server:
                    serve_client(server, commands.append, watchdog=0.15)
            except Exception as error:
                errors.append(error)

        worker = threading.Thread(target=run, daemon=True)
        worker.start()
        try:
            for packet in packets:
                client.sendall(packet)
            if disconnect:
                client.shutdown(socket.SHUT_WR)
            worker.join(timeout=1)
        finally:
            client.close()
        self.assertFalse(worker.is_alive(), 'Receiver did not stop')
        self.assertEqual(errors, [])
        self.assertEqual(commands[0], 'stop')
        self.assertEqual(commands[-1], 'stop')
        return commands

    def test_split_and_batched_commands_then_disconnect(self):
        commands = self.run_connection([b'for', b'ward\nleft\nstop\n'])
        self.assertIn('forward', commands)
        self.assertIn('left', commands)

    def test_watchdog(self):
        self.assertIn('forward', self.run_connection([b'forward\n'], disconnect=False))

    def test_invalid_command_stops(self):
        commands = self.run_connection([b'forward\ninvalid\nright\n'])
        self.assertIn('forward', commands)
        self.assertNotIn('right', commands)

    def test_partial_command_does_not_keep_motor_running(self):
        self.assertIn('forward', self.run_connection([b'forward\nlef'], disconnect=False))


if __name__ == '__main__':
    unittest.main()
