"""PC側。--host なしではEV3に送信せず画面上だけで確認する。"""
import argparse
import socket
import time
from pathlib import Path
from hand_motion import MotionController


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', help='EV3のBluetooth側IPアドレス')
    parser.add_argument('--port', type=int, default=5000)
    parser.add_argument('--camera', type=int, default=0)
    args = parser.parse_args()
    import cv2
    import mediapipe as mp

    model = Path(__file__).resolve().with_name('hand_landmarker.task')
    if not model.is_file():
        raise FileNotFoundError(str(model))
    # 同期的に結果を取得するためVIDEOモードを使用する。
    options = mp.tasks.vision.HandLandmarkerOptions(
        base_options=mp.tasks.BaseOptions(model_asset_path=str(model)),
        running_mode=mp.tasks.vision.RunningMode.VIDEO,
        num_hands=1)
    controller = MotionController()
    connection = None
    cap = None
    try:
        cap = cv2.VideoCapture(args.camera)
        if not cap.isOpened():
            raise RuntimeError('カメラを開けませんでした')
        with mp.tasks.vision.HandLandmarker.create_from_options(options) as landmarker:
            previous_timestamp = -1
            previous_command = None
            last_send = 0.0
            while True:
                ok, frame = cap.read()
                if not ok:
                    raise RuntimeError('カメラ画像を取得できませんでした')
                # 鏡像にして画面の左右と操作を合わせる。
                frame = cv2.flip(frame, 1)
                image = mp.Image(image_format=mp.ImageFormat.SRGB,
                                 data=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                captured_at = time.monotonic()
                timestamp_ms = max(previous_timestamp + 1, int(captured_at * 1000))
                previous_timestamp = timestamp_ms
                result = landmarker.detect_for_video(image, timestamp_ms)
                points = result.hand_landmarks[0] if result.hand_landmarks else None
                command = controller.update(points, captured_at)
                now = time.monotonic()
                if now - captured_at > 0.3:
                    controller.reset()
                    command = 'stop'
                # カメラ・モデル・初回推論が完了してから接続する。
                # 初期化中にEV3側の受信タイムアウトが発生するのを防ぐ。
                if args.host and connection is None:
                    connection = socket.create_connection((args.host, args.port), timeout=1)
                    connection.settimeout(0.2)
                    connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    controller.reset()
                    command = 'stop'
                    now = time.monotonic()
                    print('Connected to EV3: {}'.format(args.host))
                if connection and (command != previous_command or now - last_send >= 0.1):
                    connection.sendall((command + '\n').encode('ascii'))
                    last_send = now
                if command != previous_command:
                    print(command)
                previous_command = command
                height, width = frame.shape[:2]
                zone = controller.dead_zone
                cv2.rectangle(frame,
                              (int((0.5 - zone) * width), int((0.5 - zone) * height)),
                              (int((0.5 + zone) * width), int((0.5 + zone) * height)),
                              (0, 255, 255), 2)
                cv2.putText(frame, 'STOP', (int(0.45 * width), int(0.5 * height)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
                if points:
                    for point in points:
                        cv2.circle(frame, (int(point.x * width), int(point.y * height)),
                                   3, (0, 255, 0), -1)
                    palm_x = sum(points[i].x for i in (0, 5, 9, 13, 17)) / 5
                    palm_y = sum(points[i].y for i in (0, 5, 9, 13, 17)) / 5
                    cv2.circle(frame, (int(palm_x * width), int(palm_y * height)),
                               8, (255, 0, 255), -1)
                mode = 'EV3' if connection else 'PREVIEW'
                cv2.putText(frame, '{}: {}'.format(mode, command), (15, 35),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
                cv2.putText(frame, 'Hold position to drive | Center / fist = STOP | q = quit',
                            (15, 65), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
                cv2.imshow('Hand EV3 control', frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
    finally:
        if connection:
            try:
                connection.sendall(b'stop\n')
            except OSError:
                pass
            connection.close()
        if cap is not None:
            cap.release()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
